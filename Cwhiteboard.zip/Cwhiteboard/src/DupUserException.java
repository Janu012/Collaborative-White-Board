
class DupUserException extends RuntimeException
{
  public DupUserException() { super(); }
  public DupUserException(String s) { super(s); }
}